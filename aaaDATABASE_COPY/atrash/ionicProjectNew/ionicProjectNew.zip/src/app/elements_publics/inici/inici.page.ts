import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inici',
  templateUrl: './inici.page.html',
  styleUrls: ['./inici.page.scss'],
})
export class IniciPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
